/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data.mahasiswa;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author tamami <tamami.oka@gmail.com>
 */
public class MainUI extends Application {
    
    private static DaftarMahasiswaUI mhsUI;
    private static EntryDataUI entryUI;
    private static Stage primaryStage;
    
    private void initComponent(Stage stage) {
        mhsUI = new DaftarMahasiswaUI(stage);
        entryUI = new EntryDataUI();
    }
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        initComponent(primaryStage);

        if(mhsUI == null) {
            throw new Exception("Aplikasi error, UI Daftar Mahasiswa belum disiapkan");
        }

        mhsUI.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    // getter and setter

    public static DaftarMahasiswaUI getMhsUI() { return mhsUI; }

    public static EntryDataUI getEntryUI() { return entryUI; }

    public static Stage getPrimaryStage() { return primaryStage; }
    
}
