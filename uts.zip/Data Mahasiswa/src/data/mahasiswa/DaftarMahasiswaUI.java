package data.mahasiswa;

import static data.mahasiswa.MainUI.getPrimaryStage;
import java.io.File;
import java.util.Iterator;
import java.util.LinkedList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.joda.time.DateTime;

/**
 *
 * @author tamami <tamami.oka@gmail.com>
 */
public class DaftarMahasiswaUI {
    
    private Stage stage;
    
    private VBox vbox;
    
    private Scene scene;
    private TableView tblMahasiswa;
    private Button btnEntryData;
    private Button btnUbahData;
    private Button btnExport;
    private Button btnImport;
    
    // @TODO:  soal 2: tambahkan objek dengan nama "data" dengan tipe data
    //         berupa ObservableList yang berada di paket javafx.collections, 
    //         jangan lupa tambahkan sifat generalization pada objek ini agar
    //         mudah untuk melakukan proses input dan keluaran datanya
    
    public DaftarMahasiswaUI(Stage stage) {
        this.stage = stage;
        stage.setTitle("Data Mahasiswa");
        data = FXCollections.observableArrayList();
        
        initComponents();
    }
    
    private void initComponents() {
        vbox = new VBox(5);
        vbox.getChildren().addAll(new Label("Daftar Mahasiswa"));

        tblMahasiswa = new TableView();
        tblMahasiswa.setEditable(false);
        TableColumn nimCol = new TableColumn("NIM");
        TableColumn namaCol = new TableColumn("Nama");
        TableColumn tempatLahirCol = new TableColumn("Tempat Lahir");
        TableColumn tglLahirCol = new TableColumn("Tanggal Lahir");
        TableColumn jenisKelaminCol = new TableColumn("Jenis Kelamin");
        TableColumn alamatCol = new TableColumn("Alamat");
        nimCol.setCellValueFactory(new PropertyValueFactory<Mahasiswa, String>("nim"));
        namaCol.setCellValueFactory(new PropertyValueFactory<Mahasiswa, String>("nama"));
        tempatLahirCol.setCellValueFactory(new PropertyValueFactory<Mahasiswa, String>("tempatLahir"));
        tglLahirCol.setCellValueFactory(new PropertyValueFactory<Mahasiswa, String>("tanggalLahir"));
        jenisKelaminCol.setCellValueFactory(new PropertyValueFactory<Mahasiswa, String>("jenisKelamin"));
        alamatCol.setCellValueFactory(new PropertyValueFactory<Mahasiswa, String>("alamat"));
        tblMahasiswa.getColumns().addAll(nimCol, namaCol, tempatLahirCol, tglLahirCol, jenisKelaminCol, alamatCol);
        tblMahasiswa.setItems(data);
        vbox.getChildren().addAll(tblMahasiswa);

        btnEntryData = new Button("Tambah Data");
        btnUbahData = new Button("Ubah Data");
        btnExport = new Button("Export");
        btnImport = new Button("Import");

        HBox hbox = new HBox(5);
        hbox.setAlignment(Pos.CENTER_RIGHT);
        hbox.setPadding(new Insets(5, 5, 5, 5));
        hbox.getChildren().addAll(btnEntryData, btnUbahData, btnExport, btnImport);
        vbox.getChildren().addAll(hbox);

        btnEntryData.setOnAction(new BtnEntryDataOnClick());
        btnUbahData.setOnAction(new BtnUbahDataOnClick());
        btnExport.setOnAction(new BtnExportOnClick());
        btnImport.setOnAction(new BtnImportOnClick());

        scene = new Scene(vbox, 700, 400);
    }
    
    public void show() {
        getPrimaryStage().setTitle("Daftar Mahasiswa");
        getPrimaryStage().setScene(scene);
        getPrimaryStage().show();
    }
    
    public int isExists(String nim) {
        for(int i=0; i<data.size(); i++) {
            if(data.get(i).getNim().equals(nim)) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Method ini akan menambahkan data mahasiswa ke dalam Collection "data"
     * yang sudah dibuat di atas.
     * 
     * @TODO: Soal 3: Buat objek Mahasiswa untuk menampung isi parameternya, 
     *                kemudian objek Mahasiswa tersebut ditambahkan ke objek
     *                ObservableList yang sudah dibuat pada soal 2.
     *                jika selesai menambahkan data, kirimkan nilai true
     */
    public boolean addData(String nim, String nama, String tempatLahir, DateTime tglLahir,
                           String jnsKelamin, String alamat) {
    }
    
    /**
     * Method ini akan mengubah data mahasiswa yang berada dalam Collection "data"
     * yang sudah dibuat diatas.
     * 
     * @TODO: Soal 4: Buat objek Mahasiswa untuk menampung isi parameter nim, 
     *                nama, tempatLahir, tglLahir, jnsKelamin, dan alamat.
     *                Kemudian ubah data mahasiswa yang berada pada 
     *                objek ObservableList (data) diatas dengan objek Mahasiswa
     *                baru ini berdasarkan parameter index (idx) yang ada.
     *                Kembalikan nilai true jika sudah selesai
     */
    public boolean updateData(int idx, String nim, String nama, String tempatLahir, DateTime tglLahir,
                              String jnsKelamin, String alamat) {
    }
    
    /**
     * Method ini akan menghapus data mahasiswa pada objek ObservableList (data)
     * berdasarkan indexnya
     * 
     * @TODO Soal 5: Hapus data mahasiswa pada objek ObservableList (data) 
     *               berdasarkan parameter index (idx) yang diberikan,
     *               kemudian kembalikan nilai true bila telah selesai
     */
    public boolean hapus(int idx) {
    }
    
    /**
     * Method ini akan mengubah ObservableList menjadi Serializable agar dapat
     * dikirimkan ke file atau jaringan
     * 
     * @param data adalah objek ObservableList yang akan dijadikan serializable
     * @return objek LinkedList yang sudah serializable
     */
    private LinkedList<Mahasiswa> convertToListSerializable(ObservableList<Mahasiswa> data) {
        LinkedList<Mahasiswa> result = new LinkedList();

        Iterator<Mahasiswa> it = data.iterator();
        while(it.hasNext()) {
            result.add(it.next());
        }
        return result;
    }    
    
    /**
     * Method ini mengisikan objek ObservableList dengan LinkedList yang 
     * dan langsung memperbarui tabel UI.
     * 
     * @param data adalah objek LinkedList yang akan dijadikan bahan isian tabel UI
     */
    private void setData(LinkedList<Mahasiswa> data) {
        this.data.removeAll(this.data);
        this.data = FXCollections.observableList(data);
        tblMahasiswa.setItems(this.data);
    }
    
    /**
     * Method ini akan menyimpan ObservableList (isi tabel UI) ke dalam file
     * 
     * @TODO: Soal 6: Kirimkan objek LinkedList (list) yang telah dibuat ke dalam file (file).
     *                jangan lupa bahwa objek mahasiswa dalam LinkedList harus berupa serializable.
     *                jika proses selesai, kembalikan nilai true, namun bila terjadi exception
     *                kembalikan nilai false.
     * 
     * @param file adalah file yang akan diisikan dengan objek Collection
     * @return nilai true bila prosesnya berhasil, dan false bila terjadi exception
     */
    private boolean exportData(File file) {
        LinkedList list = convertToListSerializable(data);
    }
    
    /**
     * Method ini mengambil data dari file kemudian mengembalikan hasilnya dalam bentuk
     * LinkedList.
     * 
     * @TODO: Soal 7: Ambil objek LinkedList dari file (file) dan simpan dalam objek "data".
     *                perhatikan bahwa nilai yang dikembalikan berupa objek LinkedList.
     *                Bila gagal mengambil data dari file, maka hasil yang dikembalikan
     *                adalah null, namun bila file berhasil diakses dan datanya disimpan dalam 
     *                objek "data", maka objek "data" yang dikembalikan.
     * 
     * @param file adalah file yang akan diambil datanya
     * @return LinkedList yang siap untuk digunakan sebagai sumber data pada tabel UI.
     */
    private LinkedList<Mahasiswa> importData(File file) {
        LinkedList<Mahasiswa> data = null;
    }
    
    
    // -- alert
    private void panggilPesanInformasi(String header, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informasi");
        alert.setHeaderText(header);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void panggilPesanError(String header, String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Kesalahan");
        alert.setHeaderText(header);
        alert.setContentText(msg);
        alert.showAndWait();
    }
    
    
    // -- inner class -- event
    
    private class BtnEntryDataOnClick implements EventHandler<ActionEvent> {

        public void handle(ActionEvent event) {
            MainUI.getEntryUI().show(EntryDataUI.ADD_DATA);
            MainUI.getPrimaryStage().centerOnScreen();
            MainUI.getPrimaryStage().requestFocus();
        }
    }

    private class BtnUbahDataOnClick implements EventHandler<ActionEvent> {

        @SuppressWarnings("Since15")
        public void handle(ActionEvent event) {
            if(tblMahasiswa.getSelectionModel().getSelectedIndex() == -1) {
                panggilPesanInformasi("Informasi Ubah Data",
                    "Silahkan pilih dahulu data yang akan diubah");
                return;
            }

            TablePosition pos = (TablePosition) tblMahasiswa.getSelectionModel().getSelectedCells().get(0);
            int row = pos.getRow();

            Mahasiswa item = (Mahasiswa) tblMahasiswa.getItems().get(row);

            MainUI.getEntryUI().getTfNim().setText(item.getNim());
            MainUI.getEntryUI().getTfNim().setEditable(false);
            MainUI.getEntryUI().getTfNama().setText(item.getNama());
            MainUI.getEntryUI().getTfTempatLahir().setText(item.getTempatLahir());
            MainUI.getEntryUI().getDpTglLahir().setValue(LocalDate.of(
                    Integer.parseInt(item.getTanggalLahir().substring(6,10)),
                    Integer.parseInt(item.getTanggalLahir().substring(3,5)),
                    Integer.parseInt(item.getTanggalLahir().substring(0,2))));
            MainUI.getEntryUI().getCbJenisKelamin().setValue(item.getJenisKelamin());
            MainUI.getEntryUI().getTaAlamat().setText(item.getAlamat());

            MainUI.getEntryUI().show(EntryDataUI.EDIT_DATA);
            MainUI.getPrimaryStage().centerOnScreen();
            MainUI.getPrimaryStage().requestFocus();
            MainUI.getEntryUI().getTfNama().requestFocus();
        }
    }

    private class BtnExportOnClick implements EventHandler<ActionEvent> {
        public void handle(ActionEvent event) {
            FileChooser fileDialog = new FileChooser();
            fileDialog.setTitle("Simpan Data");
            File file = fileDialog.showSaveDialog(stage);
            if(exportData(file)) {
                panggilPesanInformasi("Informasi Simpan",
                    "File berhasil terbentuk dan data sudah tersimpan");
            } else {
                panggilPesanError("Kesalahan Simpan",
                    "Data tidak bisa di ekspor ke file");
            }
        }
    }

    private class BtnImportOnClick implements EventHandler<ActionEvent> {

        public void handle(ActionEvent event) {
            FileChooser fileDialog = new FileChooser();
            fileDialog.setTitle("Muatkan Data");
            File file = fileDialog.showOpenDialog(stage);
            LinkedList<Mahasiswa> data = importData(file);
            if(data != null) {
                setData(data);
                panggilPesanInformasi("Informasi Buka File",
                    "Data telah di-import dari file");
            } else {
                panggilPesanError("Kesalahan Buka File",
                    "Data tidak bisa di import dari file");
            }
        }
    }
    
}
