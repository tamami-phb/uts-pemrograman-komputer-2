package data.mahasiswa;

/**
 * @TODO: 
 * Soal 1 :
 * Kelas ini akan menampung data berikut :
 * NIM dengan tipe data String
 * Nama dengan tipe data String
 * Tempat Lahir dengan tipe data String
 * Tanggal Lahir dengan tipe data DateTime dari pustaka joda-time versi 2.9.9
 * Jenis Kelamin dengan tipe data String
 * Alamat dengan tipe data String
 * 
 * semua properti/variabel harus dijadikan private dengan disediakan 
 * getter dan setter method untuk mengaksesnya
 * 
 * Perhatikan bahwa kelas ini nantinya akan dimasukkan dalam collection 
 * dan dapat disimpan ke dalam file.
 *
 * @author tamami <tamami.oka@gmail.com>
 */
class Mahasiswa {
    
}
